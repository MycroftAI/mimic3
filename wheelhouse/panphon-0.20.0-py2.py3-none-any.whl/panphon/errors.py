# -*- coding: utf-8 -*-


class SegmentError(Exception):
    pass
