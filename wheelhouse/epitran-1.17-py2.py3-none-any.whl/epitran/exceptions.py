# -*- coding: utf-8 -*-


class MappingError(Exception):
    pass


class DatafileError(Exception):
    pass
