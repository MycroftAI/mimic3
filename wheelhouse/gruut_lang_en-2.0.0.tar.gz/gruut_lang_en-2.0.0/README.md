# gruut English

Language-specific files for English (en) in [gruut](https://github.com/rhasspy/gruut)
