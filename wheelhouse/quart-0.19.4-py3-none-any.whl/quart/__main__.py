from __future__ import annotations

if __name__ == "__main__":
    from .cli import main

    main()
